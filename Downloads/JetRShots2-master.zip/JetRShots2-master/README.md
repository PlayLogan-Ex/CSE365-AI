# JetRShots2
MVP App on DribbbleAPI. List shots/like/comment/view profile/profile followers and likes. Used: MVP/Retrofit 2/Dagger 2/RxJava/ButterKnife/Picasso/Retrolalmbda/Android Support/EventBus/
