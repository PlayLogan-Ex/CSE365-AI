package vardemin.com.jetrshots2.util;

public class Constant {
    public static final String BASE_URL = "https://api.dribbble.com/v1/";
    public static final String AUTH_URL = "https://dribbble.com/oauth/";
    public static final String CLIENT_ID = "6c5f7da61bb001cee4ab8a2c9a1cfa03b2336ee1e185d224436d14f039112814";
    public static final String CLIENT_SECRET = "bc98301fa4ff436a6ae5ebe253c8481ac50366bf35c6c9944c1036f34b99b5ca";
    public static final String REDIRECT_URI = "jetrshots2://vardemin.ru";
    public static final String PER_PAGE = "50";

    public static final String PROFILE_KEY = "user_id";
    public static final String COMMENT_KEY = "shot_id";
}
