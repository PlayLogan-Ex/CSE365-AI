# WeixinCommentListDemo

仿微信实现的朋友圈，模拟与后台交互实现了点赞、评论、删除等功能，listview可以根据键盘的显示或隐藏实现联动。
![image](https://github.com/Naoki2015/CircleDemo/blob/master/CircleDemo/imgs/01.png)
![image](https://github.com/Naoki2015/CircleDemo/blob/master/CircleDemo/imgs/02.png)
![image](https://github.com/Naoki2015/CircleDemo/blob/master/CircleDemo/imgs/03.png)
