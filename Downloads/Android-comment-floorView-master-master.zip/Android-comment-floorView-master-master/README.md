# 仿网易新闻的评论楼层View

**网易的楼层效果图**


![网易楼层的效果](http://img.blog.csdn.net/20160331094321580)

**该View的效果图**

![自定义的效果](http://img.blog.csdn.net/20160331094541127)

![自定义的效果](http://img.blog.csdn.net/20160331094556456)

**具体讲解**

[查看详细](http://blog.csdn.net/u013435893/article/details/51023519)
