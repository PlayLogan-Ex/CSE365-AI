package com.ithaha.floorview;

/**
 * @author: Long
 * @Date: 2016/3/30 15:40
 * 每个评论所需要的
 */
public interface Commentable {

	int getCommentFloorNum();

	String getCommentContent();

	String getAuthorName();
}
