package com.example.guest.discussionforum;

public class Constants {
    public static final String FIREBASE_CHILD_THREADS = "threads";
}
